package com.LearnJava.Program;

public class RelationalOperator {
	public static void main(String[] args) {
		//boolean a = 10 < 20 ;
		//System.out.println(a);
		System.out.println("10 < 20 = "+(10 < 20));
		System.out.println("10 > 20 = "+(10 > 20));
		System.out.println("10 == 20 = "+(10 == 20));
		System.out.println("10 != 20 = "+(10 != 20));
		
		System.out.println("10 <= 10 = "+(10 <= 10));
		System.out.println("20 >= 20 = "+(20 <= 20));
	}
}
